export const LOGIN = 'LOGIN';
export const PROJECT = 'PROJECT';
export const CONNECT = 'CONNECT';
export const TABTYPE = 'TABTYPE';