export const BUSINESSUNITLIST = [
  {
    value: "Customer Analytics",
    label: "Customer Analytics",
  },
  {
    value: "Campaign Management",
    label: "Campaign Management",
  },
  { value: "Loyalty", label: "Loyalty" },
  {
    value: "Customer Engagement",
    label: "Customer Engagement",
  },
  { value: "Content and Media", label: "Content and Media" },
  {
    value: "Customer Data Management",
    label: "Customer Data Management",
  },
  { value: "POS/In-Store", label: "POS/In-Store" },
  { value: "Ecommerce", label: "Ecommerce" },
  { value: "Customer Service", label: "Customer Service" },
  { value: "Reservations", label: "Reservations" },
  { value: "Payments", label: "Payments" },
  {
    value: "Performance Management",
    label: "Performance Management",
  },
  {
    value: "Product Management",
    label: "Product Management",
  },
  { value: "Pricing", label: "Pricing" },
  { value: "Promotions", label: "Promotions" },
  {
    value: "Planning and Replinishment",
    label: "Planning and Replinishment",
  },
  {
    value: "Category Management",
    label: "Category Management",
  },
  { value: "Sourcing", label: "Sourcing" },
  {
    value: "Warehouse Management",
    label: "Warehouse Management",
  },
  {
    value: "Transportation Management",
    label: "Transportation Management",
  },
  { value: "Vendor Management", label: "Vendor Management" },
  {
    value: "International Trade Management",
    label: "International Trade Management",
  },
  { value: "Store Operations", label: "Store Operations" },
  {
    value: "Services Operations",
    label: "Services Operations",
  },
  {
    value: "Corporate Services",
    label: "Corporate Services",
  },
  { value: "HR", label: "HR" },
  { value: "Finance", label: "Finance" },
  { value: "Legal", label: "Legal" },
  {
    value: "Real Estate and Facilities",
    label: "Real Estate and Facilities",
  },
  {
    value: "Business Intelligence",
    label: "Business Intelligence",
  },
  {
    value: "Business Resilience",
    label: "Business Resilience",
  },
  {
    value: "Information Management",
    label: "Information Management",
  },
  {
    value: "IT Business Administration",
    label: "IT Business Administration",
  },
  {
    value: "IT Business Strategy",
    label: "IT Business Strategy",
  },
  {
    value: "IT Customer Relationship",
    label: "IT Customer Relationship",
  },
  { value: "IT Strategy", label: "IT Strategy" },
  { value: "Pos Execution", label: "Pos Execution" },
  {
    value: "Service and Solution Deployment",
    label: "Service and Solution Deployment",
  }
];
