import HowItWork from "../components/howitwork"

export default function How_it_work() {
  return (
    <HowItWork/>
  )
}