import DataModernization from "../components/dataModernization"
export default function How_it_work() {
  return (
    <DataModernization/>
  )
}