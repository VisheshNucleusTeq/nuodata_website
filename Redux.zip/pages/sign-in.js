import SignIn from "../components/signIn";

function Sign_in(props) {
    return (
        <SignIn/>
    );
}

export default Sign_in;