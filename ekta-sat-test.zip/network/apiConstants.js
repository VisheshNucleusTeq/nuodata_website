export const LOGIN = "user-mgmt/v1/login";
