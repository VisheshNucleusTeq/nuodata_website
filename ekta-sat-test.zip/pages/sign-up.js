import SignUp from "../components/signUp";

function Sign_up(props) {
    return (
        <SignUp/>
    );
}

export default Sign_up;